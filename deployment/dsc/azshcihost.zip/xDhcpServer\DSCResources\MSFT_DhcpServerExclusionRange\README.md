# Description

The DhcpServerExclusionRange DSC resource manages exclusion ranges on server level.
level.

## Requirements

- Target machine must be running Windows Server 2012 R2 or later.
- Target machine must be running at minimum Windows PowerShell 5.0.
